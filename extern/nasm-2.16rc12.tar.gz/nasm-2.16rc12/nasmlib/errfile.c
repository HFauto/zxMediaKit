#include "compiler.h"

FILE *error_file;

