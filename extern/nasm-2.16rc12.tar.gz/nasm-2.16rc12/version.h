#ifndef NASM_VERSION_H
#define NASM_VERSION_H
#define NASM_MAJOR_VER      2
#define NASM_MINOR_VER      15
#define NASM_SUBMINOR_VER   99
#define NASM_PATCHLEVEL_VER 102
#define NASM_VERSION_ID     0x020f6366
#define NASM_VER            "2.16rc12"
#endif /* NASM_VERSION_H */
